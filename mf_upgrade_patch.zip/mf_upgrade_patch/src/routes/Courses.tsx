import React, { useEffect, useState } from 'react';
import { collection, onSnapshot, query } from 'firebase/firestore';
import { db } from '../firebase';

export default function Courses(){
  const [courses, setCourses] = useState<any[]>([]);
  useEffect(()=>{
    const q = query(collection(db,'courses'));
    const unsub = onSnapshot(q, snap => setCourses(snap.docs.map(d=>({ id:d.id, ...d.data() }))) );
    return ()=>unsub();
  },[]);

  return (
    <div className="grid md:grid-cols-3 gap-4">
      {courses.map(c=> (
        <div key={c.id} className="bg-white p-4 rounded shadow">
          <h3 className="font-semibold">{c.title}</h3>
          <div className="text-xs text-gray-500">{c.hours}h • {c.modules} modules</div>
          <div className="mt-2"><button className="btn">Open</button></div>
        </div>
      ))}
    </div>
  );
}
