import React from 'react';
export default function Reports(){
  return (
    <div className="grid md:grid-cols-2 gap-4">
      <div className="bg-white p-4 rounded shadow">Deals Report</div>
      <div className="bg-white p-4 rounded shadow">Training Impact</div>
    </div>
  );
}
