import React, { useEffect, useState } from 'react';
import { collection, onSnapshot, query } from 'firebase/firestore';
import { db } from '../firebase';
import KanbanBoard from '../components/KanbanBoard';

const STAGES = ['new','contacted','docs','underwrite','offer','closed'];

export default function KanbanPipeline(){
  const [clients, setClients] = useState<any[]>([]);
  useEffect(()=>{
    const q = query(collection(db,'clients'));
    const unsub = onSnapshot(q, snap => setClients(snap.docs.map(d=>({ id:d.id, ...d.data() }))) );
    return ()=>unsub();
  },[]);

  const columns = STAGES.map(s=>({ id: s, title: s.toUpperCase(), items: clients.filter(c=>c.stage===s) }));

  return <KanbanBoard columns={columns} />;
}
