import React, { useEffect, useState } from 'react';
import { collection, onSnapshot, query, orderBy } from 'firebase/firestore';
import { db } from '../firebase';
import ClientCard from '../components/ClientCard';

export default function Clients(){
  const [clients, setClients] = useState<any[]>([]);

  useEffect(()=>{
    const q = query(collection(db,'clients'), orderBy('createdAt','desc'));
    const unsub = onSnapshot(q, snap => {
      setClients(snap.docs.map(d=>({ id: d.id, ...d.data()})));
    });
    return ()=>unsub();
  },[]);

  return (
    <div className="grid md:grid-cols-3 gap-4">
      {clients.map(c=> <ClientCard key={c.id} client={c} />)}
    </div>
  );
}
