import React from 'react';
export default function Dashboard(){
  return (
    <div className="grid md:grid-cols-3 gap-4">
      <div className="bg-white p-4 rounded shadow">Dashboard widgets here</div>
      <div className="bg-white p-4 rounded shadow">Pipeline quick view</div>
      <div className="bg-white p-4 rounded shadow">Training progress</div>
    </div>
  );
}
