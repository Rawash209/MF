import React, { useEffect, useState } from 'react';
import { useParams } from 'react-router-dom';
import { doc, onSnapshot } from 'firebase/firestore';
import { db } from '../firebase';

export default function ClientPage(){
  const { id } = useParams();
  const [client, setClient] = useState<any>(null);

  useEffect(()=>{
    if(!id) return;
    const ref = doc(db,'clients',id);
    const unsub = onSnapshot(ref,snap => setClient({ id: snap.id, ...snap.data() }));
    return ()=>unsub();
  },[id]);

  if(!client) return <div>Loading...</div>;

  return (
    <div className="grid md:grid-cols-3 gap-6">
      <div className="col-span-2">
        <div className="bg-white p-4 rounded shadow">
          <h2 className="text-lg font-semibold">{client.fullName}</h2>
          <p className="text-sm text-gray-600">Stage: {client.stage} • Loan: {client.loanType}</p>

          <section className="mt-4">
            <h3 className="font-medium">Notes & Timeline</h3>
            <div className="mt-2 text-sm text-gray-700">{client.notes}</div>
          </section>
        </div>
      </div>
      <aside>
        <div className="bg-white p-4 rounded shadow">
          <h3 className="font-medium">Quick Actions</h3>
          <div className="mt-2 flex flex-col gap-2">
            <button className="btn">Summarize (AI)</button>
            <button className="btn">Suggest Tasks</button>
            <button className="btn">Create Deal</button>
          </div>
        </div>
      </aside>
    </div>
  );
}
