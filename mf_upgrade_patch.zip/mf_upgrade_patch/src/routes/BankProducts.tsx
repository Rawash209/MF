import React, { useEffect, useState } from 'react';
import { collection, onSnapshot, query, orderBy } from 'firebase/firestore';
import { db } from '../firebase';

export default function BankProducts(){
  const [products, setProducts] = useState<any[]>([]);
  useEffect(()=>{
    const q = query(collection(db,'bankProducts'), orderBy('updatedAt','desc'));
    const unsub = onSnapshot(q, snap => setProducts(snap.docs.map(d=>({ id:d.id, ...d.data() }))) );
    return ()=>unsub();
  },[]);

  return (
    <div className="grid md:grid-cols-3 gap-4">
      {products.map(p=> (
        <div key={p.id} className="bg-white p-4 rounded shadow">
          <h3 className="font-semibold">{p.lender} — {p.name}</h3>
          <div className="text-sm text-gray-600">Rate: {p.rate}% • Tenure: {p.tenure} yrs</div>
        </div>
      ))}
    </div>
  );
}
