import React from 'react';
import { Link } from 'react-router-dom';

export default function ClientCard({client}:{client:any}){
  return (
    <div className="bg-white p-4 rounded shadow-sm">
      <div className="flex justify-between items-start">
        <div>
          <h3 className="font-semibold">{client.fullName}</h3>
          <div className="text-xs text-gray-500">{client.loanType} — {client.stage}</div>
        </div>
        <div className="text-right">
          <div className="text-sm">{client.amount ? `AED ${client.amount}` : ''}</div>
          <Link to={`/clients/${client.id}`} className="text-sky-600 text-xs">Open</Link>
        </div>
      </div>
    </div>
  );
}
