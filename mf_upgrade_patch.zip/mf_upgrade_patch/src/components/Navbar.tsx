import React from 'react';
import { Link } from 'react-router-dom';

export default function Navbar(){
  return (
    <header className="bg-white shadow">
      <div className="max-w-7xl mx-auto px-4 py-3 flex items-center justify-between">
        <div className="flex items-center gap-4">
          <Link to="/" className="font-bold text-xl text-sky-600">Mortgage Feeders</Link>
          <nav className="hidden md:flex gap-3 text-sm text-gray-600">
            <Link to="/clients">Clients</Link>
            <Link to="/pipeline">Pipeline</Link>
            <Link to="/courses">Courses</Link>
            <Link to="/banks">Banks</Link>
            <Link to="/reports">Reports</Link>
          </nav>
        </div>
        <div className="flex items-center gap-3">
          <div className="text-sm text-gray-600">Hi, Admin</div>
        </div>
      </div>
    </header>
  );
}
