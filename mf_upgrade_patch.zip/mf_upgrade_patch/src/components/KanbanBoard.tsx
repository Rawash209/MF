import React from 'react';

export default function KanbanBoard({columns}:{columns:any[]}){
  return (
    <div className="grid grid-cols-4 gap-4">
      {columns.map(col=> (
        <div key={col.id} className="bg-gray-100 p-3 rounded">
          <h4 className="font-semibold mb-2">{col.title} <span className="text-xs">({col.items.length})</span></h4>
          <div className="space-y-2">
            {col.items.map((it:any)=> (
              <div key={it.id} className="bg-white p-2 rounded shadow-sm">{it.fullName}</div>
            ))}
          </div>
        </div>
      ))}
    </div>
  );
}
