import React from 'react';
import { Routes, Route, Navigate } from 'react-router-dom';
import Navbar from './components/Navbar';
import Dashboard from './routes/Dashboard';
import Clients from './routes/Clients';
import ClientPage from './routes/ClientPage';
import KanbanPipeline from './routes/KanbanPipeline';
import Courses from './routes/Courses';
import BankProducts from './routes/BankProducts';
import Reports from './routes/Reports';

export default function App(){
  return (
    <div className="min-h-screen">
      <Navbar/>
      <main className="p-6 max-w-7xl mx-auto">
        <Routes>
          <Route path="/" element={<Dashboard/>} />
          <Route path="/clients" element={<Clients/>} />
          <Route path="/clients/:id" element={<ClientPage/>} />
          <Route path="/pipeline" element={<KanbanPipeline/>} />
          <Route path="/courses" element={<Courses/>} />
          <Route path="/banks" element={<BankProducts/>} />
          <Route path="/reports" element={<Reports/>} />
          <Route path="*" element={<Navigate to="/" replace />} />
        </Routes>
      </main>
    </div>
  );
}
