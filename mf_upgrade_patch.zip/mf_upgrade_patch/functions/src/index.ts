import * as functions from 'firebase-functions';
import * as admin from 'firebase-admin';
admin.initializeApp();

// Placeholder HTTP functions
export const helloWorld = functions.https.onRequest((req, res) => {
  res.send('Mortgage Feeders Functions: hello');
});
