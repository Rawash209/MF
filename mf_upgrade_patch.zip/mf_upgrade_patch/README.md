# Mortgage Feeders — Upgrade Patch (upgrade/mortgage-os)

This patch contains a production-ready scaffold for the **upgrade/mortgage-os** branch:
- React + TypeScript frontend (Vite)
- Tailwind CSS (config included)
- Firebase (Auth, Firestore, Storage) client config
- Cloud Functions scaffold for AI flows (Genkit style)
- GitHub Actions workflow for CI/CD (deploy to Firebase using FIREBASE_TOKEN)

**Project ID configured in sample files:** `mortgage-feeders-djtqc`

## How to use
1. Unzip the patch into your repo root or apply as a new branch `upgrade/mortgage-os`.
2. Update `.env` or Vite env variables with your Firebase project's keys.
3. Install:
   ```bash
   npm ci
   cd functions
   npm ci
   ```
4. Local dev:
   ```bash
   npm run dev
   ```
5. Configure Firebase CLI and set a CI token as `FIREBASE_TOKEN` in GitHub secrets.
6. Merge to `main` to trigger CI/CD.

---